/**
 * betgb 页面使用javascript
 * @copyright {@link weicms.net}
 * @author springrain<Auto generate>
 * @version  2017-02-24 10:40:57
 */


jQuery(document).ready(function(){
    //增加全选事件

});


